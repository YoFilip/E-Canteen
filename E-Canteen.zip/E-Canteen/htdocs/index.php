<?php
header("Location: zaloguj");
exit;
?>